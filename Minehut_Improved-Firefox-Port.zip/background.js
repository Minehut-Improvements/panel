fetch(browser.runtime.getURL("rules.json"))
.then((response) => response.json())
.then((rules) => {
    rules.forEach((rule) => {
        const regex = new RegExp(rule.condition.regexFilter);
        browser.webRequest.onBeforeRequest.addListener(
            (details) => {
                if (regex.test(details.url)) {
                    const newUrl = details.url.replace(regex, rule.action.redirect.regexSubstitution);
                    return { redirectUrl: newUrl };
                }
            },
            {
                urls: ["<all_urls>"], // Adjust this to target specific URLs
                types: rule.condition.resourceTypes
            },
            ["blocking"]
        );
    });
})
.catch((error) => {
    console.error("Failed to load rules:", error);
});
