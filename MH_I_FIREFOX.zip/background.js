fetch(browser.runtime.getURL("rules.json"))
.then((response) => response.json())
.then((rules) => {
    rules.forEach((rule) => {
        const regex = new RegExp(rule.condition.regexFilter);
        browser.webRequest.onBeforeRequest.addListener(
            (details) => {
                const match = details.url.match(regex);
                if (match) {
                    const newUrl = rule.action.redirect.regexSubstitution.replace("\\1", match[1]);
                    return { redirectUrl: newUrl };
                }
            },
            {
                urls: ["<all_urls>"], // Matches all URLs
                types: rule.condition.resourceTypes,
            },
            ["blocking"]
        );
    });
})
.catch((error) => {
    console.error("Failed to load rules:", error);
});
